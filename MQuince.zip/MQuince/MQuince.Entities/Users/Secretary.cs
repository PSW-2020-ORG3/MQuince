﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Entities.Users
{
    public class Secretary : Staff
    {
    }
}
