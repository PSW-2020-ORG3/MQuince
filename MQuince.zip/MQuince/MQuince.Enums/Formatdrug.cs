﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Enums
{
    public enum Formatdrug
    {
        Capsule,
        Vaccine,
        Injection
    }
}
