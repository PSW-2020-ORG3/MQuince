﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace MQuince.Enums
{
    public enum Grade
    {
        [Description("1")]
        I,
        [Description("2")]
        II,
        [Description("3")]
        III,
        [Description("4")]
        IV,
        [Description("5")]
        V
    }
}
