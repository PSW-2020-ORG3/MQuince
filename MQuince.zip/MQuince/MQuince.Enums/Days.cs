﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Enums
{
    public enum Days
    {
        Sunday,
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday
    }
}
