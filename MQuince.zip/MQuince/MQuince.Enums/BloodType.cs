﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Enums
{
    public enum BloodType
    {
        A,
        B,
        Ab,
        Zero
    }
}
