﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Enums
{
    public enum Gender
    {
        Male,
        Female
    }
}
