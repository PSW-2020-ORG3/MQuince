﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Enums
{
    public enum AbsenceType
    {
        Conference,
        WorkObligations,
        PrivateObligations,
        Vacation,
        Other
    }
}
