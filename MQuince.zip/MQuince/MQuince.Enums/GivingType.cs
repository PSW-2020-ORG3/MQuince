﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace MQuince.Enums
{

    public enum GivingType
    {
        Required,
        Forced,
        Forced1
    }
}
