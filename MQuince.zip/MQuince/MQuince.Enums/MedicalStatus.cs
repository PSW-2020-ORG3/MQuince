﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Enums
{
    public enum MedicalStatus
    {
        Active,
        Inactive
    }
}
