﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Services.Contracts.DTO.Rooms
{
    public class SectorDTO
    {
        public string Name { get; set; }
    }
}
