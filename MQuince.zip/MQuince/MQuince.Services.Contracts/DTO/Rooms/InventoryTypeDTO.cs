﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Services.Contracts.DTO.Rooms
{
    public class InventoryTypeDTO
    {
        public string Name { get; set; }
    }
}
