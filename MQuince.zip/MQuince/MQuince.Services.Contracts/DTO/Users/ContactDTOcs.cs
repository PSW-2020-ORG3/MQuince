﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Services.Contracts.DTO.Users
{
    public class ContactDTOcs
    {
        public string Number { get; set; }
        public string Email { get; set; }
    }
}
