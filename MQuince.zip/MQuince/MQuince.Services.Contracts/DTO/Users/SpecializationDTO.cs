﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Services.Contracts.DTO.Users
{
    public class SpecializationDTO
    {
        public string Name { get; set; }
    }
}
