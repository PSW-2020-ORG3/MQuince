﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Entities.DataFiltration
{
    public class StaffFilterDTO
    {
        public string StaffType { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
    }
}
