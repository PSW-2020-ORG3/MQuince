﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MQuince.Services.Contracts.DTO.MedicalRecords
{
    public class LaboratoryInstructionsDTO
    {
        public string Note { get; set; }
    }
}
